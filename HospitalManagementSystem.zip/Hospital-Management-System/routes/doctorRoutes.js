const express = require("express");
const router = express.Router();

const {
  createDoctor,
  createManyDoctors,
  getDoctors,
  getDoctorById,
  updateDoctor,
  deleteDoctor,
} = require("../controllers/doctorController");

router.post("/", createDoctor);
router.post("/bulk", createManyDoctors);
router.get("/", getDoctors);
router.get("/:id", getDoctorById);
router.put("/:id", updateDoctor);
router.delete("/:id", deleteDoctor);

module.exports = router;