const express = require("express");
const router = express.Router();

const {
  createAppointment,
  createManyAppointments,
  getAppointments,
  getAppointmentById,
  updateAppointment,
  deleteAppointment,
} = require("../controllers/appointmentController");

router.post("/", createAppointment);
router.post("/bulk", createManyAppointments);
router.get("/", getAppointments);
router.get("/:id", getAppointmentById);
router.put("/:id", updateAppointment);
router.delete("/:id", deleteAppointment);

module.exports = router;
