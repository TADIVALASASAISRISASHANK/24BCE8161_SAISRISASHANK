const express = require("express");
const router = express.Router();

const {
  createPatient,
  createManyPatients,
  getPatients,
  getPatientById,
  updatePatient,
  deletePatient,
} = require("../controllers/patientController");

router.post("/", createPatient);
router.post("/bulk", createManyPatients);
router.get("/", getPatients);
router.get("/:id", getPatientById);
router.put("/:id", updatePatient);
router.delete("/:id", deletePatient);

module.exports = router;