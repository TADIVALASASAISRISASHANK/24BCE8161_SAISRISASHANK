const express = require("express");
const router = express.Router();

const {
  createDepartment,
  createManyDepartments,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment,
} = require("../controllers/departmentController");

router.post("/", createDepartment);
router.post("/bulk", createManyDepartments);
router.get("/", getDepartments);
router.get("/:id", getDepartmentById);
router.put("/:id", updateDepartment);
router.delete("/:id", deleteDepartment);

module.exports = router;