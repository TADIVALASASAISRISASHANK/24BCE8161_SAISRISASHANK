const express = require("express");
const router = express.Router();

const {
  createMedicalRecord,
  createManyMedicalRecords,
  getMedicalRecords,
  getMedicalRecordById,
  updateMedicalRecord,
  deleteMedicalRecord,
} = require("../controllers/medicalRecordController");

router.post("/", createMedicalRecord);
router.post("/bulk", createManyMedicalRecords);
router.get("/", getMedicalRecords);
router.get("/:id", getMedicalRecordById);
router.put("/:id", updateMedicalRecord);
router.delete("/:id", deleteMedicalRecord);

module.exports = router;