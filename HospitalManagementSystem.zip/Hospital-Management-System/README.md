# Hospital Management System

## Project Overview

The Hospital Management System is a backend application developed using Node.js, Express.js, and MongoDB. The system manages patients, departments, doctors, appointments, medical records, and user authentication through RESTful APIs. It provides CRUD (Create, Read, Update, Delete) operations and demonstrates database relationship mapping using MongoDB and Mongoose.

---

## Objective

The objective of this project is to develop a backend system that efficiently manages hospital-related information such as patient details, doctor information, department records, appointment scheduling, medical records, and user authentication. The project demonstrates REST API development, database integration, authentication, and relationship mapping.

---

## Technologies Used

### Backend

* Node.js
* Express.js

### Database

* MongoDB Community Server
* MongoDB Compass

### ODM

* Mongoose

### Authentication

* JWT (JSON Web Token)
* bcryptjs

### API Testing

* Postman

### Environment Management

* dotenv

### Middleware

* cors

### IDE

* Visual Studio Code (VS Code)

---

## Project Structure

Hospital-Management-System

├── config

├── controllers

├── models

├── routes

├── screenshots

├── .env

├── package.json

├── package-lock.json

├── README.md

└── server.js

---

## Database Collections

* users
* patients
* departments
* doctors
* medicalrecords
* appointments

---

## Database Relationships

### One-to-Many Relationship

Department → Doctors

One department can have multiple doctors.

Example:

Cardiology

* Dr. Deepthi Sharma
* Other Doctors

---

### One-to-Many Relationship

Patient → Medical Records

One patient can have multiple medical records.

Example:

Rahul Sharma

* Viral Fever Record
* Common Cold Record

---

### Many-to-Many Relationship

Patient ↔ Doctor

This relationship is implemented using the Appointment collection.

Example:

Rahul Sharma → Dr. Deepthi Sharma

Rahul Sharma → Dr. Arjun Reddy

Amit Kumar → Dr. Deepthi Sharma

---

## Authentication APIs

### Register User

POST /api/auth/register

### Login User

POST /api/auth/login

Features:

* Password Hashing using bcryptjs
* JWT Token Generation
* Secure User Authentication

---

## Patient APIs

* POST /api/patients
* GET /api/patients
* GET /api/patients/:id
* PUT /api/patients/:id
* DELETE /api/patients/:id

---

## Department APIs

* POST /api/departments
* GET /api/departments
* GET /api/departments/:id
* PUT /api/departments/:id
* DELETE /api/departments/:id

---

## Doctor APIs

* POST /api/doctors
* POST /api/doctors/bulk
* GET /api/doctors
* GET /api/doctors/:id
* PUT /api/doctors/:id
* DELETE /api/doctors/:id

---

## Medical Record APIs

* POST /api/medicalrecords
* POST /api/medicalrecords/bulk
* GET /api/medicalrecords
* GET /api/medicalrecords/:id
* PUT /api/medicalrecords/:id
* DELETE /api/medicalrecords/:id

---

## Appointment APIs

* POST /api/appointments
* POST /api/appointments/bulk
* GET /api/appointments
* GET /api/appointments/:id
* PUT /api/appointments/:id
* DELETE /api/appointments/:id

---

## Backend URL

Local Development Server:

http://localhost:5000

---

## Installation

Install Dependencies:

npm install

Run Server:

npm run dev

---

## Environment Variables

Create a `.env` file in the project root directory and add the following variables:

PORT=5000

MONGO_URI=mongodb://localhost:27017/hospitalDB

JWT_SECRET=hospital_secret_key

These environment variables are used for server configuration, MongoDB database connection, and JWT token generation.

---

## Features

* Patient Management
* Department Management
* Doctor Management
* Appointment Scheduling
* Medical Record Management
* User Authentication
* Password Encryption
* JWT Token Generation
* CRUD Operations
* RESTful APIs
* MongoDB Integration
* Relationship Mapping

---

## Conclusion

The Hospital Management System is a backend application developed using Node.js, Express.js, MongoDB, and JWT Authentication. The project demonstrates RESTful API development, CRUD operations, authentication, MongoDB integration, and relationship mapping between entities. It provides an efficient platform for managing hospital-related information in a secure and organized manner.
