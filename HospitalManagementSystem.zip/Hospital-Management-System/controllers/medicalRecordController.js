const MedicalRecord = require("../models/MedicalRecord");

const createMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.create(req.body);
    res.status(201).json(record);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getMedicalRecords = async (req, res) => {
  try {
    const records = await MedicalRecord.find()
      .populate("patientId");

    res.status(200).json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createManyMedicalRecords = async (req, res) => {
  try {
    const records = await MedicalRecord.insertMany(req.body);
    res.status(201).json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getMedicalRecordById = async (req, res) => {
  try {
    const record = await MedicalRecord.findById(req.params.id)
      .populate("patientId");

    if (!record) {
      return res.status(404).json({
        message: "Medical Record not found",
      });
    }

    res.status(200).json(record);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!record) {
      return res.status(404).json({
        message: "Medical Record not found",
      });
    }

    res.status(200).json(record);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.findByIdAndDelete(req.params.id);

    if (!record) {
      return res.status(404).json({
        message: "Medical Record not found",
      });
    }

    res.status(200).json({
      message: "Medical Record deleted successfully",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createMedicalRecord,
  createManyMedicalRecords,
  getMedicalRecords,
  getMedicalRecordById,
  updateMedicalRecord,
  deleteMedicalRecord,
};